import { Component } from '@angular/core';

@Component({
  selector: 'app-order-history-dialoge',
  templateUrl: './order-history-dialoge.component.html',
  styleUrls: ['./order-history-dialoge.component.css']
})
export class OrderHistoryDialogeComponent {

}
