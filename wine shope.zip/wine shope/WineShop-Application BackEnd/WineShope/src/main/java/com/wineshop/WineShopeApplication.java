package com.wineshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WineShopeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WineShopeApplication.class, args);
		System.out.println("Running.....");
	}

}
